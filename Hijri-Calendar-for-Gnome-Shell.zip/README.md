To install:
* Create a directory in `~/.local/share/gnome-shell/extensions/` and name it `HijriCalendar@oxygenws.com`
* Copy all files in the repository to the above directory (`~/.local/share/gnome-shell/extensions/HijriCalendar@oxygenws.com/`)
* Restart Gnome-shell. (ALT+F2, r, Enter)
